package week6Assignment_Assert_Runner;


import io.cucumber.testng.CucumberOptions;
import week6Assignment_Assert_steps.Base;


@CucumberOptions(features="src/test/java/week6Assignment_Assert_Feature/CreateLead.feature",glue="week6Assignment_Assert_steps",monochrome=true,publish=true)
public class Runner extends Base {

}
                                                                                              