package week6Assignment_Hooks_Steps;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MergeLead extends Base {

	@When("Click on MergeLeads")
	public void click_on_merge_leads() {

		driver.findElement(By.xpath("//a[text()='Merge Leads']")).click();
	}

	@Then("MergeLead Page needs to be shown")
	public void merge_lead_page_needs_to_be_shown() {
		if (driver.getTitle().equals("Merge Leads | opentaps CRM")) {
			System.out.println("Merge Leads Page is showing");
		} else {
			System.out.println("Merge Leads Page is not showing");
		}
	}

	@Given("FromLead as {string} as {string}")
	public void from_lead_as(String FirstName, String LastName) throws InterruptedException {
		driver.findElement(By.xpath("(//img[@alt='Lookup'])[1]")).click();
		Set<String> allWindows = driver.getWindowHandles();
		List<String> allhandles = new ArrayList<String>(allWindows);
		driver.switchTo().window(allhandles.get(1));
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(FirstName);
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(LastName);
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		driver.switchTo().window(allhandles.get(0));

	}

	@Given("ToLead as {string} as {string}")
	public void to_lead_as(String FirstName, String LastName1) throws InterruptedException {
		driver.findElement(By.xpath("(//img[@alt='Lookup'])[2]")).click();
		Set<String> windowHandles = driver.getWindowHandles();
		ArrayList<String> arrayList = new ArrayList<String>(windowHandles);
		driver.switchTo().window(arrayList.get(1));
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(FirstName);
		driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(LastName1);
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		driver.switchTo().window(arrayList.get(0));

	}

	@When("Click on Merge")
	public void click_on_merge() {
		driver.findElement(By.xpath("//a[text()='Merge']")).click();
		driver.switchTo().alert().accept();
	}

}
