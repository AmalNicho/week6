package week6Assignment_Hooks_Steps;

import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Learn_Hooks extends Base {
	
	@Before
	@Given("Open ChromeBrowser")
	public void open_chrome_browser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Given("Load URL")
	public void load_url() {
		driver.get("http://leaftaps.com/opentaps/");
	}


}
