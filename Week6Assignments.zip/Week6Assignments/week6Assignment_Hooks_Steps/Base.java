package week6Assignment_Hooks_Steps;

import org.openqa.selenium.chrome.ChromeDriver;

public class Base {
	
	public static ChromeDriver driver;

}
