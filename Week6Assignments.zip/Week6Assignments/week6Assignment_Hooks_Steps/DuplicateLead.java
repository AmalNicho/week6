package week6Assignment_Hooks_Steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DuplicateLead extends Base {

@When("Click on Duplicate Lead")
public void click_on_duplicate_lead() {
	driver.findElement(By.xpath("//a[text()='Duplicate Lead']")).click();
}
@Then("Duplicate Lead Page needs to be shown")
public void duplicate_lead_page_needs_to_be_shown() {
   if(driver.getTitle().equals("Duplicate Lead | opentaps CRM")) {
	   System.out.println("Duplicate Lead page shown");
   }
   else {
	   System.out.println("Duplicate Lead is not shown");
   }
}

@Given("Industry as {string}")
public void Industry_as(String Industry) {
	WebElement selects = driver.findElement(By.id("createLeadForm_industryEnumId"));
	Select x = new Select(selects);
	x.selectByVisibleText(Industry);

}

@When("Click Create Lead")
public void click_create_lead() {
driver.findElement(By.xpath("//input[@value='Create Lead']")).click();
	
}


}
