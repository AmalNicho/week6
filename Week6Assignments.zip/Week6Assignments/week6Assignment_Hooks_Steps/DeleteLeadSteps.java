package week6Assignment_Hooks_Steps;

import org.openqa.selenium.By;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DeleteLeadSteps extends Base {
	
	@When("Click on DeleteLead")
	public void click_on_delete_lead() {
	 driver.findElement(By.xpath("//a[text()='Delete']")).click();
	}
	@Then("MyLead Page needs to be shown")
	public void my_lead_page_needs_to_be_shown() {

		if(driver.getTitle().equals("My Leads | opentaps CRM")) {
			System.out.println("Leads has been deleted");
		} else {
			System.out.println("Leads has not deleted");
		}
	}

}
