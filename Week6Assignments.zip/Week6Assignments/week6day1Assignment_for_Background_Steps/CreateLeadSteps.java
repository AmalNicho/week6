package week6day1Assignment_for_Background_Steps;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateLeadSteps {

	public static ChromeDriver driver;

	@Given("Open ChromeBrowser")
	public void open_chrome_browser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Given("Load URL")
	public void load_url() {
		driver.get("http://leaftaps.com/opentaps/");
	}

	@Given("Provide Username as {string}")
	public void provide_username(String Username) {
		driver.findElement(By.id("username")).sendKeys(Username);

	}

	@Given("Provide Password as {string}")
	public void provide_password(String Password) {
		driver.findElement(By.id("password")).sendKeys(Password);
	}

	@When("Click on Submit")
	public void click_on_submit() {
		driver.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
	}

	@Then("CRM\\/SFA Link")
	public void crm_sfa_link() {
		boolean displayed = driver.findElement(By.xpath("//a[contains(text(),'CRM/SFA')]")).isDisplayed();
		if (displayed) {
			System.out.println("LeafApps application is open");
		} else {
			System.out.println("LeafApps application is not open");
		}
	}

	@When("Click on CRM\\/SFA Link")
	public void click_on_crm_sfa_link() {
		driver.findElement(By.xpath("//a[contains(text(),'CRM/SFA')]")).click();
	}

	@Then("MyHome Page needs to be shown")
	public void my_home_page_needs_to_be_shown() {
		String title = driver.getTitle();
		if (title.equals("My Home | opentaps CRM")) {
			System.out.println("My Home is displayed");

		} else {
			System.out.println("My Home is not displayed");
		}
	}

	@When("Click on CreateLead")
	public void click_on_create_lead() {
		driver.findElement(By.xpath("//a[text()='Create Lead']")).click();
	}

	@Then("CreateLead Page needs to be shown")
	public void create_lead_page_needs_to_be_shown() {
		String title2 = driver.getTitle();
		if (title2.equals("Create Lead | opentaps CRM")) {
			System.out.println("Create Lead is displayed");
		} else {
			System.out.println("Create Lead is not displayed");
		}
	}

	@Given("Provide CompanyName as {string}")
	public void provide_company_name(String CompanyName) {
		driver.findElement(By.xpath("//input[@id='createLeadForm_companyName']")).sendKeys(CompanyName);
	}

	@Given("Provide FirstName as {string}")
	public void provide_first_name_as(String FirstName) {
		driver.findElement(By.xpath("//input[@id='createLeadForm_firstName']")).sendKeys(FirstName);
	}
	@Given("Provide LastName as {string}")
	public void provide_last_name_as(String LastName) {
		driver.findElement(By.xpath("//input[@id='createLeadForm_lastName']")).sendKeys(LastName); 
	}

	
	
	
	
	
	@When("Click on CreateLeadsubmit")
	public void click_on_create_leadsubmit() {
		driver.findElement(By.xpath("//input[@class='smallSubmit']")).click();

	}

	@Then("View Lead needs to be show with details")
	public void view_lead_needs_to_be_show_with_details() {
		String title3 = driver.getTitle();
		if (title3.equals("View Lead | opentaps CRM")) {
			System.out.println("View Lead is displayed");
		} else {
			System.out.println("view Lead is not displayed");
		}
	}
}