package week6Assignment_Assert_steps;

import org.openqa.selenium.By;
import org.testng.Assert;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DeleteLeadSteps extends Base {

	@When("Click on DeleteLead")
	public void click_on_delete_lead() {
		driver.findElement(By.xpath("//a[text()='Delete']")).click();
	}

	@Then("MyLead Page needs to be shown")
	public void my_lead_page_needs_to_be_shown() {

		String title = driver.getTitle();

		Assert.assertEquals(title, "My Leads | opentaps CRM");
	}

}
