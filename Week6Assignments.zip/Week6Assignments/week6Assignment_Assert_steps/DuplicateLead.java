package week6Assignment_Assert_steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DuplicateLead extends Base {

@When("Click on Duplicate Lead")
public void click_on_duplicate_lead() {
	driver.findElement(By.xpath("//a[text()='Duplicate Lead']")).click();
}
@Then("Duplicate Lead Page needs to be shown")
public void duplicate_lead_page_needs_to_be_shown() {
      String title = driver.getTitle();
   Assert.assertEquals(title,"Duplicate Lead | opentaps CRM");
}

@Given("Industry as {string}")
public void Industry_as(String Industry) {
	WebElement selects = driver.findElement(By.id("createLeadForm_industryEnumId"));
	Select x = new Select(selects);
	x.selectByVisibleText(Industry);

}

@When("Click Create Lead")
public void click_create_lead() {
driver.findElement(By.xpath("//input[@value='Create Lead']")).click();
	
}


}
