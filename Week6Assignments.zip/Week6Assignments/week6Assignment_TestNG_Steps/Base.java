package week6Assignment_TestNG_Steps;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;

import io.cucumber.java.en.Given;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Base extends AbstractTestNGCucumberTests {
	
	public static ChromeDriver driver;

	@BeforeMethod
//	@Given("Open ChromeBrowser")
	public void open_chrome_browser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/");
	}
//@BeforeMethod	
////@Given("Load URL")
//	public void load_url() {
//		
//	}

	
}
