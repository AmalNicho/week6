package week6Assignment_TestNG_Runner;


import io.cucumber.testng.CucumberOptions;
import week6Assignment_TestNG_Steps.Base;

@CucumberOptions(features="src/test/java/week6Assignment_TestNG_Feature/CreateLead.feature",glue="week6Assignment_TestNG_Steps",monochrome=true,publish=true)
public class Runner extends Base {

}
                                                                                              