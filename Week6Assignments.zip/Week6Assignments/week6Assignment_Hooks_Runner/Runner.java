package week6Assignment_Hooks_Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/test/java/week6Assignment_Hooks_Feature/CreateLead.feature",glue="week6Assignment_Hooks_Steps",monochrome=true,publish=true)
public class Runner extends AbstractTestNGCucumberTests {

}
                                                                                              