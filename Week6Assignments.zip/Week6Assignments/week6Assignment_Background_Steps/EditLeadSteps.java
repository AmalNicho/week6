package week6Assignment_Background_Steps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EditLeadSteps extends Base {

//	@Given("Open ChromeBrowser")
//	public void open_chrome_browser() {
//		WebDriverManager.chromedriver().setup();
//		driver = new ChromeDriver();
//		driver.manage().window().maximize();
//	}
//
//	@Given("Load URL")
//	public void load_url() {
//		driver.get("http://leaftaps.com/opentaps/");
//	}
//
//	@Given("Provide Username as {string}")
//	public void provide_username(String Username) {
//		driver.findElement(By.id("username")).sendKeys(Username);
//
//	}
//
//	@Given("Provide Password as {string}")
//	public void provide_password(String Password) {
//		driver.findElement(By.id("password")).sendKeys(Password);
//	}
//
//	@When("Click on Submit")
//	public void click_on_submit() {
//		driver.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
//	}
//
//	@Then("CRM\\/SFA Link")
//	public void crm_sfa_link() {
//		boolean displayed = driver.findElement(By.xpath("//a[contains(text(),'CRM/SFA')]")).isDisplayed();
//		if (displayed) {
//			System.out.println("LeafApps application is open");
//		} else {
//			System.out.println("LeafApps application is not open");
//		}
//	}
//
//	@When("Click on CRM\\/SFA Link")
//	public void click_on_crm_sfa_link() {
//		driver.findElement(By.xpath("//a[contains(text(),'CRM/SFA')]")).click();
//	}
//
//	@Then("MyHome Page needs to be shown")
//	public void my_home_page_needs_to_be_shown() {
//		String title = driver.getTitle();
//		if (title.equals("My Home | opentaps CRM")) {
//			System.out.println("My Home is displayed");
//
//		} else {
//			System.out.println("My Home is not displayed");
//		}
//	}
//

	@When("Click on Leads")
	public void click_on_leads() {
		driver.findElement(By.xpath("//a[text()='Leads']")).click();

	}

	@Then("MyLeads Page needs to be shown")
	public void my_leads_page_needs_to_be_shown() {
		if (driver.getTitle().equals("My Leads | opentaps CRM")) {
			System.out.println("My Leads is displayed");
		} else {
			System.out.println("My Leads is not displayed");
		}

	}

	@When("Click on FindLeads")
	public void click_on_find_leads() {
		driver.findElement(By.xpath("//a[text()='Find Leads']")).click();
	}

	@Then("FindLead Page needs to be shown")
	public void find_lead_page_needs_to_be_shown() {
		if (driver.getTitle().equals("Find Leads | opentaps CRM")) {
			System.out.println("View Leads is displayed");
		} else {
			System.out.println("View Leads is not displayed");
		}

	}

	@Given("FirstName as {string}")
	public void first_name_as(String FirstName) {
		driver.findElement(By.xpath("(//input[@name='firstName'])[3]")).sendKeys(FirstName);

	}

	@Given("LastName as {string}")
	public void last_name_as(String LastName) {
		driver.findElement(By.xpath("(//input[@name='lastName'])[3]")).sendKeys(LastName);
	}

	@Given("CompanyName as {string}")
	public void company_name_as(String CompanyName) {
		driver.findElement(By.xpath("(//input[@name='companyName'])[2]")).sendKeys(CompanyName);
	}

	@When("Click on FindLeads submit")
	public void click_on_find_leads_submit() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
	}

	@Then("Contact needs to be shown")
	public void contact_needs_to_be_shown() {
		boolean displayed = driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a"))
				.isDisplayed();
		if (displayed) {
			System.out.println("Contact is showing");

		} else {
			System.out.println("Contact is not showing");
		}

	}

	@When("Click on Selected Contact")
	public void click_on_selected_contact() {
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
	}

	@Then("View Lead Page needs to be shown")
	public void view_lead_page_needs_to_be_shown() {
		if (driver.getTitle().equals("View Lead | opentaps CRM")) {
			System.out.println("View Lead Page is showing");
		} else {
			System.out.println("View LEad Page is not showing");
		}
	}

	@When("Click on EditLead")
	public void click_on_edit_lead() {
		driver.findElement(By.xpath("//a[text()='Edit']")).click();
	}

	@Then("EditLead Page needs to be shown")
	public void edit_lead_page_needs_to_be_shown() {
		if (driver.getTitle().equals(" opentaps CRM")) {
			System.out.println("EditLead Page is shown");
		} else {
			System.out.println("EditLead is not shown");
		}
	}

	@Given("Title as {string}")
	public void title_as(String Title) {
		driver.findElement(By.id("updateLeadForm_generalProfTitle")).sendKeys(Title);
	}

	@Given("Ownership as {string}")
	public void ownership_as(String Ownership) {

		WebElement Ownerships = driver.findElement(By.id("updateLeadForm_ownershipEnumId"));
		Select select = new Select(Ownerships);
		select.selectByVisibleText(Ownership);

	}

	@When("Click on Update button")
	public void click_on_update_button() {
		driver.findElement(By.xpath("//input[@value='Update']")).click();
	}

}
